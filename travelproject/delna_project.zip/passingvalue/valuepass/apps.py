from django.apps import AppConfig


class ValuepassConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'valuepass'
