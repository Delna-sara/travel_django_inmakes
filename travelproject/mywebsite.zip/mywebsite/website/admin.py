from django.contrib import admin
from.models import Places,team_members
admin.site.register(Places)
admin.site.register(team_members)
# Register your models here.
